﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista3ex2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double valor1;
            double valor2;

            Console.WriteLine("digite o primeiro valor");
            valor1 = double.Parse(Console.ReadLine());

            do
            {
                Console.WriteLine("digiteo o segundo valor");
                valor2 = double.Parse(Console.ReadLine());
            }
while (valor1 < valor2);

            
        }  
    }
}
