﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exe6Lista3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int numero;
            int valor;
            int c;

            do
            {
                Console.Clear();
                Console.WriteLine("Digite dois valores,sendo o 2º 1º");
                Console.WriteLine("Digite o primeiro valor");
                numero = Convert.ToInt16(Console.ReadLine());
                Console.WriteLine("Digite o segundo valor");
                valor = Convert.ToInt16(Console.ReadLine());
            }
            while (numero > valor) ;
            Console.WriteLine("Digite o intervalo a ser calculada a sua tabuada? ");
            c = int.Parse(Console.ReadLine());

            for (int f = 1; f <= c; f++)
            {
                Console.WriteLine(numero + " x " + f + " = " + f);
            }
        }
    }
}
