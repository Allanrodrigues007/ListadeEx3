﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exe13Lista3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            char escolha;
            do
            {
                double i, numero, fatorial;
                Console.WriteLine("Informe o número");
                numero = double.Parse(Console.ReadLine());

                fatorial = numero;
                for (i = numero - 1; i >= 1; i--)
                {
                    Console.WriteLine($"{fatorial} * {i}");

                    fatorial = fatorial * i;

                    Console.WriteLine($"i={i}");
                    Console.WriteLine($"fatorial={fatorial}");
                    Console.WriteLine("  ");
                }
                Console.WriteLine($"\nFatorial de {numero} é {fatorial} ");

                do
                {
                    Console.WriteLine("Deseja executar o programa novamente? (S) para sim, (N) para não.");
                    escolha = char.Parse(Console.ReadLine());

                } while (escolha != 'S' && escolha != 'N');

            } while (escolha != 'N');
        }
    }
}
