﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lista3ex1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double valor;

            Console.WriteLine("digite um valor");
            double.Parse(Console.ReadLine());

            do
            {
                Console.WriteLine("digite o valor novamente");
                valor = double.Parse(Console.ReadLine());
            }
            while (valor<=0);
        }
    }
}
