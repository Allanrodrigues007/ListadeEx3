﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exe12Lista3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            char escolha;
            do
            {
                double numeros = 0;
                double a = 0;
                double p = 0;
                double n = 0;
                double valor = 0;
                double maior = 0;
                double menor = 0;
                double soma = 0;
                double ma = 0;
                double pp = 0;
                double pn = 0;



                Console.WriteLine("Digite a quantidade de valores, sendo positivo e menor que 20");
                numeros = double.Parse(Console.ReadLine());
                while (numeros < 0 || numeros >= 20)
                {
                    Console.WriteLine("Erro!!!, Informe a quantidade de valores mais uma vez...");
                    numeros = double.Parse(Console.ReadLine());
                }

                Console.WriteLine("");

                while (a < numeros)
                {
                    a++;
                    Console.Write("{0}º Valor: ", a);
                    valor = double.Parse(Console.ReadLine());
                    if (a == 1)
                    {
                        maior = menor = valor;
                    }
                    else
                    {
                        if (valor > maior)
                        {
                            maior = valor;
                        }
                        else
                        {
                            if (valor < menor)
                            {
                                menor = valor;
                            }
                        }
                    }
                    soma = soma + valor;
                    if (valor >= 0)
                    {
                        p++;
                    }
                    else
                    {
                        n++;
                    }
                }
                ma = soma / numeros;
                pp = p * 100 / numeros;
                pn = n * 100 / numeros;

                Console.WriteLine("\n\nMaior Valor: {0}", maior);
                Console.WriteLine("Menor Valor: {0}", menor);
                Console.WriteLine("A soma dos valores declarados foi: {0}", soma);
                Console.WriteLine("A media aritmetica dos valores declarados foi: {0}", ma);
                Console.WriteLine("A porcentagem positiva dos valores declarados foi de: {0}%", pp);
                Console.WriteLine("A porcentagem negativa dos valores declarados foi de: {0}%", pn);

                Console.WriteLine("");
                do
                {
                    Console.WriteLine("Executar Novamente o programa? (S) para sim, (N) para Não?");
                    escolha = char.Parse(Console.ReadLine());

                } while (escolha != 'S' && escolha != 'N');
            } while (escolha == 'S');
        }
    }
}
